# Can you trace one reported result back to the approval you kept?

Choose one shareable test operation from a workflow you receive results for. A synthetic operation recorded through your usual workflow is suitable. You can keep the original records on your system and share a short account of what you found.

### Before opening the result

Write down what you need to decide when the result arrives. Identify the approval from the records your system had already retained. This might be an internal approval ID, the original attachment, or a reference to it. Note which system kept it and which version you have. Record what you can establish now, before opening the result. Keep this selection for both observations.

### When the result arrives

Include the result and repeat the same check. If it cites another record, follow that reference and note which original, if any, it identifies. If you normally use a lookup table to connect an approval ID to a record, include what that lookup establishes and where the mapping came from.

For the two [published DPS refund examples](https://github.com/Laurent-Lemonnier/dps-scitt-decision-layer/tree/89e6853ad65c606739d9e7c163e9b1fe927ac22e/interop), the local comparison accepts a typed SHA-256 reference to the exact bytes of the approval-stage attachment (A1). A later attachment can contain the same approval history and still have a different digest. With an internal ID alone, file identity stays open unless a separate record links that ID to the attachment. For another operation, use the records and verification method from your own system. The example tool accepts only the two pinned packets and their fixture key.

To run those examples yourself, use the maintainer-supplied `refund-recipient-examples.zip`. The archive includes the receiver, input files and English instructions. [Run the fixed examples](README.md)

### Record the outcome

Distinguish which file you identified from what you could decide about the operation. If a link is missing, naming the two records you could not connect is a useful outcome. Note whether the second observation changed your decision or saved a lookup you normally make.

```text
Decision I needed to make:
Approval I had already retained (kind, version, source):
Before the result arrived — records available and conclusion:
After the result arrived — kind of result, new evidence and conclusion:
How I traced it to my approval (direct reference or lookup), or where the link was missing:
What this changed for my next action:
```
