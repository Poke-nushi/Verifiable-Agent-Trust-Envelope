# Trace a refund result to the approval file you selected

Run the receiver on two published examples of a €120 refund. They share business identifiers but cite different approval files. Keeping your selection fixed while changing the packet shows which result cites the file you chose.

## Set up

Start in a fresh directory containing `refund-recipient-examples.zip`, supplied by the VATE maintainer. The archive contains the receiver, the original fixture files and two ready-to-use references. These commands use a POSIX shell and a regular CPython 3.14 installation. Setup uses hash-pinned binary packages from PyPI. The comparisons then run offline.

```sh
python3.14 -m zipfile -e refund-recipient-examples.zip .
cd refund-recipient-examples
python3.14 -m venv .venv
.venv/bin/python -m pip --isolated --disable-pip-version-check install --index-url https://pypi.org/simple --only-binary=:all: --require-hashes -r requirements.txt
```

## Choose the approval, then compare the packets

The selection in `examples/selected-18.json` identifies the exact bytes of the approval-stage attachment (A1) from case 18. The receiver takes this reference as a separate input.

```json
{
  "type": "org.decisionprovenancestandard.action_binding_attachment",
  "alg": "SHA-256",
  "digest": "0c51d7ce4bc9a94aeb40d904464c65105639bde953fa3350602aa865685c2023"
}
```

Run both complete packets with that same selection.

```sh
.venv/bin/python -IB probe.py --case 18 --phase complete --receiver-ref examples/selected-18.json > case-18.json
.venv/bin/python -IB probe.py --case 18b --phase complete --receiver-ref examples/selected-18.json > case-18b.json
.venv/bin/python - <<'PY'
import json
from pathlib import Path

for name in ("case-18.json", "case-18b.json"):
    report = json.loads(Path(name).read_bytes())
    print(name, report["packet_result"], report["cited_reference"], report["association_with_originals"])
PY
```

| Output | Packet check | Does it cite the selected A1? | With both cited originals present |
| --- | --- | --- | --- |
| `case-18.json` | `VERIFIED` | `matched` | `matched` |
| `case-18b.json` | `VERIFIED` | `mismatch` | `mismatch` |

Use `examples/selected-18b.json` to reverse the selection. Omit `--receiver-ref` to leave it unset. A business approval ID needs a separately retained link to the original attachment to serve as a file reference.

## Recheck when the cited result receipt arrives

Case 18 originals are in `upstream/interop/one-chain/out/positive/`. Case 18b uses `upstream/interop/one-chain-real/out/positive/`. In the same shell, start with the packet, its fixture key, A1 and the allow receipt. The packet already cites a result receipt. Record the first assessment, then add the cited receipt file and rerun with the same packet and approval selection.

```sh
sample=upstream/interop/one-chain/out/positive
work=$(mktemp -d)
received="$work/received"
mkdir "$received"
cp "$sample/dispute-packet.json" "$sample/packet-keys.json" "$sample/action-binding-attachment-a1.json" "$sample/receipt-3.cbor" "$received/"
.venv/bin/python -IB probe.py --delivery-dir "$received" --receiver-ref examples/selected-18.json > "$work/before.json"
cp "$sample/receipt-4.cbor" "$received/"
.venv/bin/python -IB probe.py --delivery-dir "$received" --receiver-ref examples/selected-18.json > "$work/after.json"
.venv/bin/python - "$work/before.json" "$work/after.json" <<'PY'
import json
import sys
from pathlib import Path

for path in map(Path, sys.argv[1:]):
    report = json.loads(path.read_bytes())
    print(path.stem, report["packet_result"], report["cited_reference"],
          report["association_with_originals"], report["evidence"]["packet_blocking_references"])
PY
printf 'Saved both reports in %s\n' "$work"
```

| Time | Packet check | A1 reference | Association with originals | Blocking reference |
| --- | --- | --- | --- | --- |
| Before | `FAILED` | `matched` | `not_assessed` | `tool_result_receipt` |
| After | `VERIFIED` | `matched` | `matched` | none |

The packet and key go directly in the delivery directory. Keep the selection and output files outside it. `evidence.cited_originals` shows which cited files are present. `association_reason` explains the receiver's decision. A match identifies the cited files. Each report lists what remains open under `evidence.not_checked_by_this_comparison`, including direct comparison of the approved operation, target, amount and other parameters against the execution record, and actual settlement.

The receiver accepts the two fixed packets and their fixture key. To try the question with a record from your own system, use the [one-operation worksheet](RECIPIENT-TRIAL.md).

The comparison code uses the [VATE repository license](LICENSE). The original verifier and fixture files are included unchanged from `Laurent-Lemonnier/dps-scitt-decision-layer` at `89e6853ad65c606739d9e7c163e9b1fe927ac22e`. [Pinned source](https://github.com/Laurent-Lemonnier/dps-scitt-decision-layer/tree/89e6853ad65c606739d9e7c163e9b1fe927ac22e/interop) · [Upstream license](upstream/LICENSE) · [Source file hashes](SOURCES.json)
