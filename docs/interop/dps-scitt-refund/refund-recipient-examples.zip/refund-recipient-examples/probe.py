"""Offline comparison on two frozen refund fixtures. Prints deterministic JSON."""

import argparse
import hashlib
import importlib.util
import json
import re
from functools import cache
from importlib.metadata import version
from pathlib import Path

import cbor2


HERE = Path(__file__).resolve().parent
PIN = "89e6853ad65c606739d9e7c163e9b1fe927ac22e"
MANIFEST_HASH = "20773cd32cffe0ff4ed3de214f507181682cf91927feef92af261b8664ad5ef1"
CHOICES_HASH = "1c3b419a614bbffd91443129bc1ffaa59eb8ca62da5cc7514cafb67c0a392e05"
SOURCE = HERE / "upstream"
PACKAGES = {"18": "interop/one-chain", "18b": "interop/one-chain-real"}
A1 = "action-binding-attachment-a1.json"
A2 = "action-binding-attachment-a2.json"
PACKET = "dispute-packet.json"
KEYS = "packet-keys.json"
SIG = "signatures-attachment.json"
VERDICTS = ("verdict-record.json", "verdict-record-other-result.json")
RECEIPTS = tuple(f"receipt-{i}.cbor" for i in range(6))
ATTACHMENT_TYPE = "org.decisionprovenancestandard.action_binding_attachment"
SIGNATURE_TYPE = "org.decisionprovenancestandard.signatures_attachment"
RECEIPT_TYPE = "org.ietf.draft-thaha-scitt-agent-execution-evidence-02.execution_receipt"
APPROVAL_ANCHOR = "approval_event_hash.dps_approval.attachment (extension beyond -01)"
EVIDENCE_TYPES = {
    A1: ATTACHMENT_TYPE, A2: ATTACHMENT_TYPE, SIG: SIGNATURE_TYPE,
    **dict.fromkeys(VERDICTS, "verdict-record/1"),
    **dict.fromkeys(RECEIPTS, RECEIPT_TYPE),
}
COMPLETE = (PACKET, KEYS, A1, A2, SIG, *VERDICTS, *RECEIPTS)
PHASES = {
    "approval_only": (A1,),
    "packet_without_dps_attachments": tuple(f for f in COMPLETE if f not in (A1, A2)),
    "packet_without_execution_receipts": tuple(f for f in COMPLETE if f not in RECEIPTS),
    "complete": COMPLETE,
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checked(path, digest):
    raw = path.read_bytes()
    require(sha(raw) == digest, f"source digest mismatch: {path}")
    return raw


@cache
def source_manifest():
    manifest = json.loads(checked(HERE / "SOURCES.json", MANIFEST_HASH))
    require(manifest["commit"] == PIN, "wrong upstream pin")
    return manifest


@cache
def fixture_hashes(name):
    sources = source_manifest()["files"]
    return {sources[f"{directory}/out/positive/{name}"]["sha256"]: case
            for case, directory in PACKAGES.items()}


def receiver_reference(path):
    if path is None:
        return None
    value = json.loads(path.read_bytes())
    if not (
        isinstance(value, dict) and set(value) == {"type", "alg", "digest"}
        and value["type"] == ATTACHMENT_TYPE and value["alg"] == "SHA-256"
        and isinstance(value["digest"], str) and re.fullmatch("[0-9a-f]{64}", value["digest"])
    ):
        raise ValueError("expected a typed SHA-256 reference to a DPS action-binding attachment")
    return value


def held_items(files):
    groups = {}
    for relative, raw in files.items():
        if relative in (PACKET, KEYS):
            continue
        kind = EVIDENCE_TYPES[Path(relative).name]
        if kind == RECEIPT_TYPE:
            # These fixtures use canonical CBOR as the receipt hash basis.
            require(cbor2.dumps(cbor2.loads(raw), canonical=True) == raw,
                    f"non-canonical execution receipt: {relative}")
        groups.setdefault(kind, set()).add(sha(raw))
    return groups


def read_delivery(directory):
    require(directory.is_dir() and not directory.is_symlink(), "expected a regular delivery directory")
    files = {}
    folders = [directory]
    while folders:
        # iterdir propagates an unreadable directory as an input error.
        for path in sorted(folders.pop().iterdir()):
            relative = path.relative_to(directory).as_posix()
            require(not path.is_symlink(), f"unexpected symlink: {relative}")
            if path.is_dir():
                folders.append(path)
                continue
            if relative in ("summary.json", "action-specification.json"):
                continue
            require(path.is_file(), f"expected a regular file: {relative}")
            require(relative in (PACKET, KEYS) or path.name in EVIDENCE_TYPES,
                    f"unexpected delivery filename: {relative}")
            files[relative] = path.read_bytes()
    return files


def native_verify(verifier, files, held):
    key = json.loads(files[KEYS])["merchant_dispute_desk_ed25519_pub"]
    return verifier(json.loads(files[PACKET]), public_key_hex=key, held=held)


def anchor(report, name):
    found = [item for item in report["re_derived"]["anchors"] if item["name"] == name]
    require(len(found) == 1, f"expected one anchor for {name}")
    return found[0]


def inspect_delivery(verifier, files):
    """Evaluate the packet and its citations against this delivery."""
    digests = {name: sha(files[name]) for name in sorted(files)}
    fixture = fixture_hashes(PACKET).get(digests.get(PACKET))
    missing = [name for name in (PACKET, KEYS) if name not in files]
    view = {
        "source_manifest_sha256": MANIFEST_HASH, "fixture_case": fixture,
        "delivered": sorted(files), "delivered_sha256": digests, "missing_inputs": missing,
        "receiver_status": "awaiting_packet", "packet_result": None,
        "packet_failures": [], "packet_result_without_originals": None, "input_error": None,
        "approval_anchor": None, "result_anchor": None, "unresolved_references": [],
    }
    if KEYS in files and digests[KEYS] not in fixture_hashes(KEYS):
        view["receiver_status"] = "untrusted_verification_key"
        return view, None
    if missing:
        if PACKET in files:
            view["receiver_status"] = "awaiting_verification_key"
        return view, None

    # Native diagnostics for bad input are distinct from absent referenced originals.
    try:
        report = native_verify(verifier, files, held_items(files))
    except (ValueError, TypeError, AttributeError, IndexError, KeyError,
            RecursionError, cbor2.CBORError) as error:
        view.update(receiver_status="invalid_input", input_error=str(error))
        return view, None

    view["packet_result"] = report["result"]
    view["packet_failures"] = report["failures"]
    anchors = report["re_derived"].get("anchors", [])
    by_name = {item["name"]: item for item in anchors}
    approval, result = by_name.get(APPROVAL_ANCHOR), by_name.get("tool_result_receipt")
    view.update(approval_anchor=approval, result_anchor=result,
                unresolved_references=[item for item in anchors if item["state"] in
                                       ("not held", "not resolved: verifier holds nothing of that type")])
    codes = {item["code"] for item in report["failures"]}
    if report["result"] != "VERIFIED" and not (
        report["result"] == "FAILED" and codes == {"ANCHOR_UNRESOLVED"}
    ):
        view["receiver_status"] = "packet_rejected"
        return view, report
    if fixture is None:
        view["receiver_status"] = "outside_fixed_examples"
        return view, report

    # A second native check isolates the signed citation from availability. It
    # can enable citation comparison only; it never upgrades the delivery verdict.
    if report["result"] == "FAILED":
        baseline = native_verify(verifier, files, {})
        view["packet_result_without_originals"] = baseline["result"]
        if baseline["result"] != "VERIFIED":
            view["receiver_status"] = "packet_rejected"
            return view, report
    require(approval is not None and result is not None, "pinned fixture omitted a required anchor")
    originals_ready = (report["result"] == "VERIFIED"
                       and approval["state"] == result["state"] == "resolved")
    view["receiver_status"] = "cited_originals_present" if originals_ready else "awaiting_referenced_originals"
    return view, report


def compare_view(verifier, files, choices):
    """Keep file possession, the receiver's choice, and the native packet verdict distinct."""
    view, report = inspect_delivery(verifier, files)
    status = view["receiver_status"]
    cited = None
    evidence = {
        "approval_reference_basis": "Typed SHA-256 of the exact bytes of the approval-stage DPS attachment (A1).",
        "cited_originals": {"approval_attachment_bytes": "not_assessed", "result_receipt_bytes": "not_assessed"},
        "packet_blocking_references": None,
        "not_checked_by_this_comparison": [
            "human_approval_signature", "approver_authority", "execution_receipt_chain", "actual_refund_settlement",
            "approved_vs_recorded_operation_target_amount_and_other_parameters",
        ],
    }
    reason = status
    if status in ("cited_originals_present", "awaiting_referenced_originals"):
        approval = view["approval_anchor"]
        cited = {field: approval[field] for field in ("type", "alg", "digest")}
        for label, item in (("approval_attachment_bytes", approval), ("result_receipt_bytes", view["result_anchor"])):
            evidence["cited_originals"][label] = "present" if item["state"] == "resolved" else "absent"
        # For these accepted citations only "not held" blocks the native packet check.
        # A type with no delivered files is also unresolved but does not cause that failure.
        evidence["packet_blocking_references"] = [
            item["name"] for item in view["unresolved_references"] if item["state"] == "not held"
        ]
        reason = "packet_check_failed" if view["packet_result"] == "FAILED" else "cited_original_missing"

    view["evidence"] = evidence
    view["receiver_choices"] = {}
    for label, choice in choices.items():
        reference = association = "not_assessed"
        association_reason = reason
        if choice is None:
            association_reason = "no_receiver_reference"
        elif cited is not None:
            reference = "matched" if choice == cited else "mismatch"
            if status == "cited_originals_present":
                association = reference
                association_reason = ("approval_attachment_digest_matches" if reference == "matched"
                                      else "approval_attachment_digest_differs")
        view["receiver_choices"][label] = {
            "cited_reference": reference, "association_with_originals": association,
            "association_reason": association_reason,
        }
    return view, report


def load_verifier(manifest):
    rel = "interop/one-chain/goshi_from_text.py"
    checked(SOURCE / rel, manifest["files"][rel]["sha256"])
    spec = importlib.util.spec_from_file_location("pinned_packet_verifier", SOURCE / rel)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify_packet


def case_file(manifest, case, name):
    rel = f"{PACKAGES[case]}/out/positive/{name}"
    return checked(SOURCE / rel, manifest["files"][rel]["sha256"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=PACKAGES)
    parser.add_argument("--phase", choices=PHASES)
    parser.add_argument("--delivery-dir", type=Path, help="only the packet, verification-key file and originals received so far")
    parser.add_argument("--receiver-ref", type=Path,
                        help="separately saved typed SHA-256 of a whole DPS attachment; compared to the cited A1")
    args = parser.parse_args()
    if bool(args.case) != bool(args.phase):
        parser.error("use --case and --phase together, or omit both for the full comparison")
    if args.delivery_dir is not None and args.case:
        parser.error("use --delivery-dir or a fixed --case/--phase")
    if args.receiver_ref is not None and not (args.case or args.delivery_dir is not None):
        parser.error("--receiver-ref requires a delivery or a fixed case/phase")
    manifest = source_manifest()
    verify = load_verifier(manifest)

    def stage(case, phase, selections):
        files = {name: case_file(manifest, case, name) for name in PHASES[phase]}
        view, native = compare_view(verify, files, selections)
        return view, native, files

    if args.case or args.delivery_dir is not None:
        try:
            selection = receiver_reference(args.receiver_ref)
            files = (read_delivery(args.delivery_dir) if args.delivery_dir is not None else
                     {name: case_file(manifest, args.case, name) for name in PHASES[args.phase]})
        except (OSError, ValueError) as error:
            parser.error(str(error))
        view, _ = compare_view(verify, files, {"supplied": selection})
        assessment = view.pop("receiver_choices")["supplied"]
        view.update({"receiver_reference": selection, **assessment})
        print(json.dumps(view, indent=2))
        return

    choices = json.loads(checked(HERE / "receiver-choices.json", CHOICES_HASH))
    choices["none"] = None
    bundle = {"upstream": PIN, "source_manifest_sha256": MANIFEST_HASH,
              "choices_file_sha256": CHOICES_HASH,
              "runtime_packages": {k: version(k) for k in ("cryptography", "cbor2")},
              "cases": {}}
    for case in PACKAGES:
        saved = json.loads(case_file(manifest, case, "summary.json"))
        published_joins = {k.split()[0]: v for k, v in saved["joins"].items()}
        require(published_joins == {f"K{i}": True for i in range(1, 13)}, "published join baseline")
        phases = {}
        for phase in PHASES:
            view, native, files = stage(case, phase, choices)
            phases[phase] = view
            for selected in choices:
                is_checkable = selected != "none" and phase != "approval_only"
                expected = ("matched" if selected == case else "mismatch") if is_checkable else "not_assessed"
                row = view["receiver_choices"][selected]
                require(row["cited_reference"] == expected, f"{case}/{phase}/{selected}: citation")
                supported = expected if phase == "complete" else "not_assessed"
                require(row["association_with_originals"] == supported, f"{case}/{phase}/{selected}: originals")

        view, native, files = stage(case, "complete", choices)
        require(native == saved["link4_packet"], f"{case}: full native report differs")
        require(sha(files[A1]) == choices[case]["digest"], f"{case}: independent choice fixture")
        held = held_items(files)
        both = {sha(case_file(manifest, selected, A1)) for selected in PACKAGES}
        require(len(both) == 2, "selection controls must be different")
        both_report = native_verify(verify, files, {**held, ATTACHMENT_TYPE: held[ATTACHMENT_TYPE] | both})
        require(both_report == native, "extra available approval changed native verdict")
        selected_runs = {}
        for selected in PACKAGES:
            # Only for this control, limit the held attachment set to one actual A1.
            just_one = {sha(case_file(manifest, selected, A1))}
            report = native_verify(verify, files, {**held, ATTACHMENT_TYPE: just_one})
            state = anchor(report, APPROVAL_ANCHOR)["state"]
            codes = [failure["code"] for failure in report["failures"]]
            expected = ("VERIFIED", "resolved", []) if selected == case else ("FAILED", "not held", ["ANCHOR_UNRESOLVED"])
            require((report["result"], state, codes) == expected, f"{case}/{selected}: projected native check")
            selected_runs[selected] = {"packet_result": report["result"], "approval_anchor_state": state,
                                       "failure_codes": codes}

        packet = json.loads(files[PACKET])
        settlement = packet["manifest"]["settlement_anchor"]["anchor"]
        parameters = json.loads(case_file(manifest, case, "action-specification.json"))["parameters"]
        a1 = json.loads(files[A1])
        scenario = {"decision_id": a1["decision_id"], "order_ref": parameters["order_ref"],
                    "action_id": packet["manifest"]["action_id"], "txn_ref": settlement["txn_ref"],
                    "amount_minor": settlement["amount_minor"], "currency": settlement["currency"]}
        bundle["cases"][case] = {
            "scenario": scenario, "packet_sha256": sha(files[PACKET]), "approval_sha256": sha(files[A1]),
            "result_record_hash": view["result_anchor"]["digest"],
            "native_packet_report_equals_published": True, "published_joins_not_rerun": published_joins,
            "phases": phases, "held_both_approval_records": both_report["result"],
            "held_one_selected_approval_record": selected_runs,
        }
    require(bundle["cases"]["18"]["scenario"] == bundle["cases"]["18b"]["scenario"], "shared scenario identifiers")
    print(json.dumps(bundle, indent=2))


if __name__ == "__main__":
    main()
